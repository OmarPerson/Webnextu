var calculadora ={//Objeto Calculadora
	
	mostrado_en_pantalla:"", //atributos 
	primer_numero:"", 
	ultimo_numero:"", 
	operacion_anterior:"", 
	ultima_operacion:"", 
	punto:function() {//Funcion para la tecla punto
		//if (calculadora.mostrado_en_pantalla == "0") {
		var display = document.getElementById('display');
		/*
		Que cuando se le de clic al punto imprima 0.y el ultimo numero 
		*/
		if (calculadora.primer_numero == "punto") {
			calculadora.mostrado_en_pantalla = ".";
			display.innerHTML = calculadora.mostrado_en_pantalla;
		}else{

		calculadora.mostrado_en_pantalla = ""+calculadora.mostrado_en_pantalla;
		display.innerHTML = "0"+calculadora.mostrado_en_pantalla;
		}
		
	
		document.getElementById('punto').addEventListener('mousedown', function(){
		document.getElementById('punto').style.width ="27%";
		});
		document.getElementById('punto').addEventListener('mouseup', function(){
		document.getElementById('punto').style.width = "29%";
		});
		//}
	},
	
	numero:function(numero){// funcion para el resto de las teclas de números
		var display = document.getElementById('display');

		if (calculadora.mostrado_en_pantalla.length < 8) {//Permite mostrar 8 digitos en el display 
			calculadora.mostrado_en_pantalla = calculadora.mostrado_en_pantalla+""+numero;
			
		}
			
		document.getElementById('0').addEventListener('mousedown', function(){
		document.getElementById('0').style.width="27%";
		});
		document.getElementById('0').addEventListener('mouseup', function(){
		document.getElementById('0').style.width="29%";
			if(calculadora.mostrado_en_pantalla == 0){//condicion para que no se imprima el 0 más veces antes de cualquier otro valor
				calculadora.mostrado_en_pantalla = "";
			}
		})
		
		document.getElementById('1').addEventListener('mousedown', function() {//Se aplica el efecto de el estilo de la tecla
		document.getElementById('1').style.width="28%";
		});
		document.getElementById('1').addEventListener('mouseup', function() {//Se aplica el efecto de el estilo de la tecla
		document.getElementById('1').style.width = "30%";
		});
		document.getElementById('2').addEventListener('mousedown', function() {
		document.getElementById('2').style.width="28%";
		});
		document.getElementById('2').addEventListener('mouseup', function() {
		document.getElementById('2').style.width = "30%";
		});
		document.getElementById('3').addEventListener('mousedown', function() {
		document.getElementById('3').style.width="29%";
		});
		document.getElementById('3').addEventListener('mouseup', function() {
		document.getElementById('3').style.width = "30%";
		});
		document.getElementById('4').addEventListener('mousedown', function(){
		document.getElementById('4').style.width ="20%";
		});
		document.getElementById('4').addEventListener('mouseup', function(){
		document.getElementById('4').style.width = "22%";
		});
		document.getElementById('5').addEventListener('mousedown', function(){
		document.getElementById('5').style.width ="20%";
		});
		document.getElementById('5').addEventListener('mouseup', function(){
		document.getElementById('5').style.width = "22%";
		});
		document.getElementById('6').addEventListener('mousedown', function(){
		document.getElementById('6').style.width ="20%";
		});
		document.getElementById('6').addEventListener('mouseup', function(){
		document.getElementById('6').style.width = "22%";
		});
		document.getElementById('7').addEventListener('mousedown', function(){
		document.getElementById('7').style.width ="20%";
		});
		document.getElementById('7').addEventListener('mouseup', function(){
		document.getElementById('7').style.width = "22%";
		});
		document.getElementById('8').addEventListener('mousedown', function(){
		document.getElementById('8').style.width ="20%";
		});
		document.getElementById('8').addEventListener('mouseup', function(){
		document.getElementById('8').style.width = "22%";
		});
		document.getElementById('9').addEventListener('mousedown', function(){
		document.getElementById('9').style.width ="20%";
		});
		document.getElementById('9').addEventListener('mouseup', function(){
		document.getElementById('9').style.width = "22%";
		});
		
		if(calculadora.ultima_operacion == ""){
			calculadora.primer_numero = parseFloat(calculadora.mostrado_en_pantalla);
		}else{
			calculadora.ultimo_numero = parseFloat(calculadora.mostrado_en_pantalla);
		}
		display.innerHTML = calculadora.mostrado_en_pantalla;//muestra los numeros en el dsplay
	},

	operacion:function(operacion){//Funcion para las teclas de operaciones
		

			
		calculadora.operacion_anterior = calculadora.ultima_operacion;
		calculadora.ultima_operacion = operacion;
		
		
		document.getElementById('igual').addEventListener('mousedown', function(){
		document.getElementById('igual').style.width ="28%";
		});
		document.getElementById('igual').addEventListener('mouseup', function(){
		document.getElementById('igual').style.width = "29%";
		});
		document.getElementById('mas').addEventListener('mousedown', function(){
		document.getElementById('mas').style.width ="85%";
		});
		document.getElementById('mas').addEventListener('mouseup', function(){
		document.getElementById('mas').style.width = "87%";
		});
		document.getElementById('menos').addEventListener('mousedown', function(){
		document.getElementById('menos').style.width ="20%";
		});
		document.getElementById('menos').addEventListener('mouseup', function(){
		document.getElementById('menos').style.width = "22%";
		});
		document.getElementById('por').addEventListener('mousedown', function(){
		document.getElementById('por').style.width ="20%";
		});
		document.getElementById('por').addEventListener('mouseup', function(){
		document.getElementById('por').style.width = "22%";
		});
		document.getElementById('dividido').addEventListener('mousedown', function(){
		document.getElementById('dividido').style.width ="20%";
		});
		document.getElementById('dividido').addEventListener('mouseup', function(){
		document.getElementById('dividido').style.width = "22%";
		});
		/*
		
		*/
		document.getElementById('raiz').addEventListener('mousedown', function(){
		document.getElementById('raiz').style.width ="20%";
		});
		document.getElementById('raiz').addEventListener('mouseup', function(){
		document.getElementById('raiz').style.width = "22%";
		
		});
		document.getElementById('sign').addEventListener('mousedown', function(){
		document.getElementById('sign').style.width ="20%";
		});
		document.getElementById('sign').addEventListener('mouseup', function(){
		document.getElementById('sign').style.width = "22%";
		
		});
		
		console.log("calculadora.operacion_anterior "+calculadora.operacion_anterior);
		console.log("calculadora.ultima_operacion "+calculadora.ultima_operacion);


		console.log("operacion "+operacion);
		var display = document.getElementById('display');
		display.innerHTML = "";
		
		calculadora.mostrado_en_pantalla = ""; 

		if(calculadora.ultimo_numero == ""){
			//no hacemos nada
		}else{
			

			console.log("generamos operacion");
			var resultado = calculadora.primer_numero;
			switch(operacion){//Condición para realizar las operaciones segun el caso
				/*
				case "sign":
					resultado = calculadora.primer_numero * -1;
					calculadora.ultimo_numero = "";
				break;
				case "raiz":
					display.innerHTML = Math.sqrt(calculadora.primer_numero);
					calculadora.ultimo_numero = "";
				break;*/
				case "mas":
					resultado = calculadora.primer_numero + calculadora.ultimo_numero;
					calculadora.ultimo_numero = "";
				break;
				case "dividido":
					resultado = calculadora.primer_numero / calculadora.ultimo_numero;
					calculadora.ultimo_numero = "";
					
				break; 
				case "por":
					resultado = calculadora.primer_numero * calculadora.ultimo_numero;
					calculadora.ultimo_numero = "";
					
				break; 
				case "menos":
					resultado = calculadora.primer_numero - calculadora.ultimo_numero;
					calculadora.ultimo_numero = "";
					
				break;
				
				/*caso especial*/
				case "igual":
					//if (resultado.length <= 8) {

						switch(calculadora.operacion_anterior){
							
							case "dividido":
								resultado = calculadora.primer_numero / calculadora.ultimo_numero;
								calculadora.ultimo_numero = ""; 
							break; 
							case "por":
								resultado = calculadora.primer_numero * calculadora.ultimo_numero;
								calculadora.ultimo_numero = ""; 
							break; 
							case "menos":
								resultado = calculadora.primer_numero - calculadora.ultimo_numero;
								calculadora.ultimo_numero = ""; 
							break;
							 
							case "mas":
								resultado = calculadora.primer_numero + calculadora.ultimo_numero;
								calculadora.ultimo_numero = "";
							break;
						}
					//}

					//}
					
				break;
				
			}
			
			//if (resultado.length <= 8) {

			console.log("resultado ="+resultado);
			//}

			display.innerHTML = parseFloat(resultado.toFixed(7));//Muestra el resultado en el display mostrando solo 8 digitos en total 	
			calculadora.primer_numero = resultado;
			calculadora.ultimo_numero = "";
			calculadora.ultima_operacion = "";
			
		}
		
	},
	/*operacion1:function() {
		document.getElementById('raiz').addEventListener('mousedown', function(){
		document.getElementById('raiz').style.width ="20%";
		});
		document.getElementById('raiz').addEventListener('mouseup', function(){
		document.getElementById('raiz').style.width = "22%";
		resultado = Math.sqrt(calculadora.primer_numero);
		calculadora.ultimo_numero = "";
		});
		document.getElementById('sign').addEventListener('mousedown', function(){
		document.getElementById('sign').style.width ="20%";
		});
		document.getElementById('sign').addEventListener('mouseup', function(){
		document.getElementById('sign').style.width = "22%";
		if (display = includes("-")) {
			resultado = calculadora.primer_numero + "";
		}else{
			resultado = calculadora.primer_numero + "-";
		}
		});
	},*/
	borrar:function(operacion){//funcion para la tecla on para que borre y muestre el 0
		//var display = document.getElementById('display');
		calculadora.mostrado_en_pantalla = "";
		display.innerHTML = calculadora.mostrado_en_pantalla+"0";
		document.getElementById('on').addEventListener('mousedown', function(){
		document.getElementById('on').style.width ="20%";
		});
		document.getElementById('on').addEventListener('mouseup', function(){
		document.getElementById('on').style.width = "22%";
		
		});
		
	}

}//Finaliza la declaracion del objeto

var teclas = document.getElementsByClassName("tecla");

for(var i = 0, j=teclas.length; i<j; i++){
    teclas[i].addEventListener("click", function(){
    	var element_id = this.getAttribute("id");//Se le asigna el valor a la tecla para que este se imprima en el display
    	console.log("click "+element_id);
    	//var display = getElementById('display');
    	//display.length = 8;
    	if (element_id.length <= 8) {

    	switch(element_id){//Condicion dependiendo del caso se realiza la operacion mandando a llamar la funcion  en las teclas operaciones y en numeros
    			
    		/*operaciones*/
    		case "on":
				calculadora.borrar(element_id.toString());
    		break;
    		case "sign":
				calculadora.operacion();
			break;
			case "raiz":
				calculadora.operacion();
			break;
			case "dividido":
				calculadora.operacion(element_id.toString());
			break; 
			case "por":
				calculadora.operacion(element_id.toString());
			break; 
			case "menos":
				calculadora.operacion(element_id.toString());
			break;
			case "punto":
				calculadora.punto(element_id.toString());//manda a llamar la funcion del punto
			break;
			case "igual":
				calculadora.operacion(element_id.toString());//manda a llamar la funcion operacion
			break;
			case "mas":
				calculadora.operacion(element_id.toString());
			break;

			/*numeros*/
			case "0":
				calculadora.numero(element_id);
			break;
			case "1":
				calculadora.numero(element_id);//Se imprime el valor de el id y se manda a llamar a la funcion del atributo numero
			break;
			case "2":
				calculadora.numero(element_id);
			break;
			case "3":
				calculadora.numero(element_id);
			break;
			case "4":
				calculadora.numero(element_id);
			break;
			case "5":
				calculadora.numero(element_id);
			break;
			case "6":
				calculadora.numero(element_id);
			break; 
			case "7":
				calculadora.numero(element_id);
			break;
			case "8":
				calculadora.numero(element_id);
			break;
			case "9":
				calculadora.numero(element_id);
			break; 
    	}
    	}
    });
 
}


